import { Component, Input, OnInit } from '@angular/core';
import { DdsComponent } from '../dds/dds.component';
import { setElementId, stringToBoolean } from '../../helpers/dds-helper';
@Component({
  selector: 'app-sidenav',
  templateUrl: './app-sidenav.component.html',
  styleUrls: ['./app-sidenav.component.scss'],
})
export class AppSidenavComponent extends DdsComponent implements OnInit {
  @Input() openState!: string;
  private isOpen!: boolean;

  ngOnInit() {
    this.ddsInitializer = `SideNav`;
    this.isOpen = stringToBoolean(this.openState);
    setElementId(this.elementId, this.ddsInitializer.toLowerCase());
  }

  expandSidenav = (e: any) => {
    if (this.ddsComponent) this.ddsComponent.expand();
  };

  collapseSidenav = (e: any) => {
    if (this.ddsComponent) this.ddsComponent.collapse();
  };
}
