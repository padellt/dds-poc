import { Component, AfterViewInit, Input } from "@angular/core";
import { createObserver, pascalDash } from "../../helpers/dds-helper";
declare var DDS: any; 
@Component({
  selector: 'dds',
  templateUrl: './dds.component.html',
  styleUrls: ['./dds.component.scss']
})
export class DdsComponent implements AfterViewInit {
  @Input() elementId: string = '';

  public ddsInitializer: string = '';
  public ddsElement: any;
  public ddsComponent: any;
  private observers: Array<any> = [];

  ngAfterViewInit() {
    this.ddsElement = document.getElementById(this.elementId);
    this.initializeNow();
    // this.initializeLater();
  }

  initializeNow = () => {
    let ddsDataElement: any;
    
    let selector: string = pascalDash(this.ddsInitializer).toLowerCase();
    selector = `[data-dds="${selector}"]`;
    
    if (this.ddsElement) {
      ddsDataElement = this.ddsElement.querySelector(selector);
      if (!ddsDataElement) {
        ddsDataElement = this.ddsElement.parentElement.querySelector(selector);
      }
      if (ddsDataElement) {
        if (DDS[this.ddsInitializer]) {
          this.ddsComponent = new DDS[this.ddsInitializer](ddsDataElement);
        }
      } else {
        console.log({
          ddsElement: this.ddsElement,
          parent: this.ddsElement.parentElement,
          error: `"${this.ddsInitializer}" not found by selector ${selector}.`
        });
      }
    } else {
      console.log(`DDS Component "${this.ddsInitializer}" not found by ID "${this.elementId}".`);
    }
  };

  initializeLater = () => {
    var waitForElements = [
      {
        selectr: `[data-dds="${pascalDash(this.ddsInitializer).toLowerCase()}"]`,
        command: (elem: any) => {
          this.ddsComponent = new DDS[this.ddsInitializer](elem);
        }
      }
    ];

    if (!this.observers) {
      this.observers = createObserver(waitForElements);
    }
  };
}
