import { Component, ViewChild } from '@angular/core';
import { AppSidenavComponent } from './components/app-sidenav/app-sidenav.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {
  title = 'dds-poc';
  @ViewChild(AppSidenavComponent)
  private sidenavComponent!: AppSidenavComponent;
  collapseSidenav(e: any) {
    this.sidenavComponent.collapseSidenav(e);
    return false;
  }

  expandSidenav(e: any) {
    this.sidenavComponent.expandSidenav(e);
    return false;
  }
}
