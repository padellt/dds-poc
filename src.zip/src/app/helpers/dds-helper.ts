const foundEls: any[] = [];

const handleFound = (elems: any[], initr: any) => {
  elems.forEach((elem) => {
    if (!foundEls.includes(elem.id)) {
      foundEls.push(elem.id);
      initr.command(elem);
    }
  });
}

export const createObserver = (waitForElements: any[]) => {
  // As assistance for delayed initialization, define an observer to watch for changes
  var observers: any[] = [];
  waitForElements.forEach(function (initr) {
    observers.push(
      new MutationObserver(function (mutations, me) {
        var targetElems: any = document.querySelectorAll(initr.selectr);
        if (targetElems.length > 0) {
          handleFound(targetElems, initr);
          me.disconnect(); // stop observing
          return;
        }
      })
    );
  });

  // start observing
  observers.forEach(function (observer) {
    observer.observe(document, {
      childList: true,
      subtree: true
    });
  });

  return observers;
}

export const Uuid = () => {
  const windowObj: any = window;
  const winCrypto = windowObj.crypto || windowObj.msCrypto;
  let index = winCrypto.getRandomValues(new Uint32Array(1))[0];
  index = +`${index}`.substr(0, 1);
  const uuid = winCrypto.getRandomValues(new Uint32Array(10))[index];
  return uuid;
}

export const setElementId = (elId: string, elName = `el`) => {
  if (elId) {
    return;
  }
  elId = `${elName}-${Uuid()}`;
}

export const stringToBoolean = (thisState: string) => {
  if (thisState === "0" || thisState === "false") {
    return false;
  }
  return true;
}

export const pascalDash = function (key: string) {
  return key.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase()
};
