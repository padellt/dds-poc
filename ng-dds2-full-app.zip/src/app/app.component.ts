import { Component, OnInit, ViewChild } from "@angular/core";
import { SidenavComponent } from "./components/sidenav/sidenav.component";
import { ModalComponent } from "./components/modal/modal.component";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"]
})
export class AppComponent implements OnInit {
  @ViewChild(SidenavComponent) private sidenavComponent: SidenavComponent;
  @ViewChild(ModalComponent) private modalComponent: ModalComponent;
  public selectValue1: Array<string> = [`Loading...`];
  public selectValue2: Array<string> = [`Loading...`];

  ngOnInit() {
    console.clear();
    this.getDelayedData();
  }

  getDelayedData(): void {
    setTimeout(()=>{
      this.selectValue1 = [
        `Matrix`,
        `Free Guy`,
        `Dark City`,
        `Demolition Man`,
      ];
    }, 750);

    setTimeout(()=>{
      this.selectValue2 = [
        `Hitchhiker's Guide to the Universe`,
        `The Princess Bride`,
        `Labyrinth`,
        `Do Androids Dream of Electric Sheep?`
      ];
    }, 1500);
  }

  collapseSidenav(e: any) {
    this.sidenavComponent.collapseSidenav(e);
    return false;
  }

  expandSidenav(e: any) {
    this.sidenavComponent.expandSidenav(e);
    return false;
  }

  openModal(e: any) {
    this.modalComponent.openModal();
  }


}
