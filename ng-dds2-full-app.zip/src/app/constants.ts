export const Constants = {
  uicore: {
    version: "1.3.1"
  }
};
