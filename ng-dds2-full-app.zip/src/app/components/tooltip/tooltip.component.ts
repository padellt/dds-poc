import { Component, Input } from '@angular/core';
import { DdsComponent } from "../../helpers/dds-component-shell";
import { setElementId } from "../../helpers/dds-helpers";

@Component({
  selector: 'app-tooltip',
  templateUrl: './tooltip.component.html',
  styleUrls: ['./tooltip.component.scss']
})
export class TooltipComponent extends DdsComponent {
  @Input() icon: string;

  ngOnInit() {
    this.ddsInitializer = `Tooltip`;
    setElementId(this.elementId, this.ddsInitializer.toLowerCase());
    if (!this.icon) {
      this.icon = `alert-info-cir`;
    }
  }

}