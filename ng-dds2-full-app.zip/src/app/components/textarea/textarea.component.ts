import { Component, Input, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { DdsComponent } from '../../helpers/dds-component-shell';
import { setElementId, Uuid, stringToBoolean } from '../../helpers/dds-helpers';

@Component({
  selector: `app-textarea`,
  templateUrl: `./textarea.component.html`,
  styleUrls: [`./textarea.component.scss`],
})
export class TextAreaComponent extends DdsComponent implements AfterViewInit {
  @ViewChild('textContainer') textContainer: ElementRef;
  @Input() isRequired: string;
  private defaultText: string;
  private textAreaId: string;
  private labelId: string;
  private helperId: string;
  private states: any = {
    required: false,
  }

  ngOnInit() {
    this.ddsInitializer = `TextArea`;
    setElementId(this.elementId, this.ddsInitializer.toLowerCase());
    this.textAreaId = `${this.ddsInitializer}-textarea${Uuid()}`;
    this.labelId = `${this.ddsInitializer}-label${Uuid()}`;
    this.helperId = `${this.ddsInitializer}-helper${Uuid()}`;
    this.states.required = stringToBoolean(this.isRequired);
  }

  ngAfterViewInit() {
    setTimeout(() => {
      if (!this.defaultText)
        this.defaultText = this.textContainer && this.textContainer.nativeElement.innerText;
    })
  }

}