import { Component, Input } from '@angular/core';
import { DdsComponent } from '../../helpers/dds-component-shell';
import { setElementId } from '../../helpers/dds-helpers';

@Component({
  selector: `app-select`,
  templateUrl: `./select.component.html`,
  styleUrls: [`./select.component.scss`],
})
export class SelectComponent extends DdsComponent {
  @Input() selectOptions: Array<string>;

  ngOnInit() {
    this.ddsInitializer = `Select`;
    setElementId(this.elementId, this.ddsInitializer.toLowerCase());
  }

}