import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";

import { AccordionComponent } from "./components/accordion/accordion.component";
import { AppComponent } from "./app.component";
import { ModalComponent } from "./components/modal/modal.component";
import { SelectComponent } from "./components/select/select.component";
import { SidenavComponent } from "./components/sidenav/sidenav.component";
import { TextAreaComponent } from "./components/textarea/textarea.component";
import { TooltipComponent } from "./components/tooltip/tooltip.component";

@NgModule({
  declarations: [
    AccordionComponent,
    AppComponent,
    ModalComponent,
    SelectComponent,
    SidenavComponent,
    TextAreaComponent
    TooltipComponent
  ],
  imports: [BrowserModule],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {}
